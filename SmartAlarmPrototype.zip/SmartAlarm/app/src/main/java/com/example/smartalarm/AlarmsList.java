package com.example.smartalarm;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Collections;

public class AlarmsList extends Fragment {
    /**
     * Activity this fragment is apart of.
     */
    private MainActivity mA;
    private ListView alarm_list_view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.alarms_list_fragment, container, false);
        // Naming toolbar.
        mA.getSupportActionBar().setTitle("Alarms");

        // Use the view for this fragment to search for UI components.
        alarm_list_view = (ListView) view.findViewById(R.id.alarm_list);
        alarm_list_view.setLongClickable(true);
        update_list_view();

        // program a short click on the list item
        alarm_list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                System.out.println("Alarm from list selected.");
                mA.edit = true;
                mA.position = position;
                mA.start_set_alarm_fragment();
            }
        });

        alarm_list_view.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int pos, long id) {
                System.out.println("Long Click Detected");
                final int fin_pos = pos;
                Alarm a = mA.alarms.get(fin_pos);
                new AlertDialog.Builder(mA)
                        .setTitle("Warning")
                        .setMessage("Delete " + a.alarm_time + " alarm?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                mA.deleteAlarm(fin_pos);
                            }})
                        .setNegativeButton(android.R.string.no, null).show();
                return true;
            }
        });

        // Setting up floating button to add an alarm
        final FloatingActionButton add = view.findViewById(R.id.add_alarm);
        add.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mA.start_set_alarm_fragment();
            }
        });

        return view;
    }

    public void update_list_view() {
        /*
        I need to book keep that fact that the switch can turn by tapping and also by updating or setting
        a new alarm.
         */

        Collections.sort(mA.alarms);

        // make array adapter to bind arraylist to listview with new custom item layout
        AlarmsAdapter aa = new AlarmsAdapter(mA, R.layout.alarm_entry, mA.alarms);
        alarm_list_view.setAdapter(aa);
        registerForContextMenu(alarm_list_view);
        aa.notifyDataSetChanged();  // to refresh items in the list
    }

    // Called at the start of the visible lifetime.
    @Override
    public void onStart(){
        super.onStart();
        Log.d ("Content Fragment", "onStart");
        // Apply any required UI change now that the Fragment is visible.
    }

    // Called at the start of the active lifetime.
    @Override
    public void onResume(){
        super.onResume();
        Log.d ("Content Fragment", "onResume");
        // Resume any paused UI updates, threads, or processes required
        // by the Fragment but suspended when it became inactive.
    }

    // Called at the end of the active lifetime.
    @Override
    public void onPause(){
        Log.d ("Content Fragment", "onPause");
        // Suspend UI updates, threads, or CPU intensive processes
        // that don't need to be updated when the Activity isn't
        // the active foreground activity.
        // Persist all edits or state changes
        // as after this call the process is likely to be killed.
        mA.getSupportActionBar().setTitle("Alarms");
        super.onPause();
    }

    // Called to save UI state changes at the
    // end of the active lifecycle.
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        Log.d ("Content Fragment", "onSaveInstanceState");
        // Save UI state changes to the savedInstanceState.
        // This bundle will be passed to onCreate, onCreateView, and
        // onCreateView if the parent Activity is killed and restarted.
        super.onSaveInstanceState(savedInstanceState);
    }

    // Called at the end of the visible lifetime.
    @Override
    public void onStop(){
        Log.d ("Content Fragment", "onStop");
        // Suspend remaining UI updates, threads, or processing
        // that aren't required when the Fragment isn't visible.
        super.onStop();
    }

    // Called when the Fragment's View has been detached.
    @Override
    public void onDestroyView() {
        Log.d ("Content Fragment", "onDestroyView");
        // Clean up resources related to the View.
        super.onDestroyView();
    }

    // Called at the end of the full lifetime.
    @Override
    public void onDestroy(){
        Log.d ("Content Fragment", "onDestroy");
        // Clean up any resources including ending threads,
        // closing database connections etc.
        super.onDestroy();
    }

    // Called when the Fragment has been detached from its parent Activity.
    @Override
    public void onDetach() {
        Log.d ("Content Fragment", "onDetach");
        super.onDetach();
    }

    // Used to access activity in fragment.
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof MainActivity){
            mA =(MainActivity) context;
        }
    }
}

